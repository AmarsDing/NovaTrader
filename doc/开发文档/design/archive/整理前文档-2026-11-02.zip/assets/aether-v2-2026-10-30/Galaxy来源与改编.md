# Galaxy 来源与改编

2026-10-31 · R6。当前演示采用Uiverse Galaxy的视觉技法，按星舰配色＋V2交互改编；新组件的状态逻辑由本项目补充。

- 上游：[uiverse-io/galaxy](https://github.com/uiverse-io/galaxy)。
- 固定版本：[adbd2adde0a299a3956ea288fb444ec01891ca41](https://github.com/uiverse-io/galaxy/tree/adbd2adde0a299a3956ea288fb444ec01891ca41)，提交日期2024-09-02；访问日2026-10-31。
- 索引：3802个HTML文件、11个目录；24条组件引用对应21个不同原始文件，另精读替代候选；不是全库代码审计。
- 许可：[MIT原文](GALAXY-LICENSE.txt)，Copyright (c) 2023 Uiverse.io。保留许可、版权与原社区作者。
- [固定版本源码及SHA-256](galaxy-source-manifest.json)：哈希属于上游原文件，不属于改编文件。

| 编号 | 改编组件 | 社区作者 | 固定版本源码 | 改编范围 |
| --- | --- | --- | --- | --- |
| GX-01 | 光掠按钮 | elijahgummer | [Buttons/elijahgummer_angry-quail-96.html](https://github.com/uiverse-io/galaxy/blob/adbd2adde0a299a3956ea288fb444ec01891ca41/Buttons/elijahgummer_angry-quail-96.html) | 把原作的高倍hover缩放改为稳定文字＋单次掠光；不用Tailwind运行时。 |
| GX-02 | 跃迁图标按钮 | adamgiebl | [Buttons/adamgiebl_quiet-duck-78.html](https://github.com/uiverse-io/galaxy/blob/adbd2adde0a299a3956ea288fb444ec01891ca41/Buttons/adamgiebl_quiet-duck-78.html) | 借鉴图标旋转与平移；缩小位移，补充防重入、取消和文字状态。 |
| GX-03 | 弹性玻璃开关 | aboalsim114 | [Toggle-switches/aboalsim114_clever-chipmunk-18.html](https://github.com/uiverse-io/galaxy/blob/adbd2adde0a299a3956ea288fb444ec01891ca41/Toggle-switches/aboalsim114_clever-chipmunk-18.html) | 修复原作display:none输入不可键盘访问；主题色替换红绿对，保留轻弹手感。 |
| GX-04 | 描线选择器 | guilhermeyohan | [Checkboxes/guilhermeyohan_white-cheetah-13.html](https://github.com/uiverse-io/galaxy/blob/adbd2adde0a299a3956ea288fb444ec01891ca41/Checkboxes/guilhermeyohan_white-cheetah-13.html) | 保留SVG描线方法，去掉原作hover即可出现勾线的误导状态。 |
| GX-05 | 滑舱分段器 | Pradeepsaranbishnoi | [Radio-buttons/Pradeepsaranbishnoi_heavy-dragonfly-92.html](https://github.com/uiverse-io/galaxy/blob/adbd2adde0a299a3956ea288fb444ec01891ca41/Radio-buttons/Pradeepsaranbishnoi_heavy-dragonfly-92.html) | 恢复原生可聚焦input；删除原作窄屏scale(0.6)，改为弹性等分。 |
| GX-06 | 聚光输入框 | adamgiebl | [Inputs/adamgiebl_hot-cat-14.html](https://github.com/uiverse-io/galaxy/blob/adbd2adde0a299a3956ea288fb444ec01891ca41/Inputs/adamgiebl_hot-cat-14.html) | 借鉴focus底线，增加固定标签、内联错误与可见键盘焦点。 |
| GX-07 | 检索透镜 | ahmedyasserdev | [Inputs/ahmedyasserdev_funny-treefrog-48.html](https://github.com/uiverse-io/galaxy/blob/adbd2adde0a299a3956ea288fb444ec01891ca41/Inputs/ahmedyasserdev_funny-treefrog-48.html) | 从原作搜索＋清空布局扩展真实本地过滤和组合输入保护。 |
| GX-08 | 光能滑轨 | Galahhad | [Inputs/Galahhad_happy-dodo-17.html](https://github.com/uiverse-io/galaxy/blob/adbd2adde0a299a3956ea288fb444ec01891ca41/Inputs/Galahhad_happy-dodo-17.html) | 保留填充轨道思路，恢复可见旋钮与键盘焦点，避免原作0尺寸thumb。 |
| GX-09 | 全息对象卡 | adamgiebl | [Cards/adamgiebl_blue-mole-92.html](https://github.com/uiverse-io/galaxy/blob/adbd2adde0a299a3956ea288fb444ec01891ca41/Cards/adamgiebl_blue-mole-92.html) | 原作多色blob统一为星舰青蓝，文字阅读面独立，补充固定状态。 |
| GX-10 | 双面档案卡 | aadium | [Cards/aadium_soft-firefox-58.html](https://github.com/uiverse-io/galaxy/blob/adbd2adde0a299a3956ea288fb444ec01891ca41/Cards/aadium_soft-firefox-58.html) | 从原作整卡hover翻转改为显式操作＋仅图形翻转，保持V2正文稳定。 |
| GX-11 | 坐标光场 | adamgiebl | [Patterns/adamgiebl_curvy-earwig-79.html](https://github.com/uiverse-io/galaxy/blob/adbd2adde0a299a3956ea288fb444ec01891ca41/Patterns/adamgiebl_curvy-earwig-79.html) | 借鉴CSS渐变网格，增加点阵方案和局部纹理切换，删除外部固定颜色。 |
| GX-12 | 轨道等待器 | Abrar-Hussain1 | [loaders/Abrar-Hussain1_lovely-rabbit-61.html](https://github.com/uiverse-io/galaxy/blob/adbd2adde0a299a3956ea288fb444ec01891ca41/loaders/Abrar-Hussain1_lovely-rabbit-61.html) | 去掉原作满屏容器和无限脉冲，补齐idle/running/done/cancelled与销毁清理。 |
| GX-13 | 光幕占位 | bundui | [loaders/bundui_fat-jellyfish-70.html](https://github.com/uiverse-io/galaxy/blob/adbd2adde0a299a3956ea288fb444ec01891ca41/loaders/bundui_fat-jellyfish-70.html) | 保留原作槽位结构，改写Tailwind脉冲为有限演示，增加取消和稳定尺寸。 |
| GX-14 | 悬浮注释 | gharsh11032000 | [Tooltips/gharsh11032000_spotty-zebra-83.html](https://github.com/uiverse-io/galaxy/blob/adbd2adde0a299a3956ea288fb444ec01891ca41/Tooltips/gharsh11032000_spotty-zebra-83.html) | 借鉴浮起小气泡，补充键盘、触屏、Esc和固定行为，移除bounce与文字替换。 |
| GX-15 | 可撤销回声 | Yaya12085 | [Notifications/Yaya12085_smooth-seahorse-63.html](https://github.com/uiverse-io/galaxy/blob/adbd2adde0a299a3956ea288fb444ec01891ca41/Notifications/Yaya12085_smooth-seahorse-63.html) | 保留原作图标/文案/动作结构，移除常驻appear循环，增加撤销与关闭状态。 |
| GX-16 | 卫星快捷动作 | bociKond | [Tooltips/bociKond_terrible-emu-64.html](https://github.com/uiverse-io/galaxy/blob/adbd2adde0a299a3956ea288fb444ec01891ca41/Tooltips/bociKond_terrible-emu-64.html) | 从原作hover社交按钮气泡扩展为显式扇面操作，加入焦点、关闭和中文标签。 |
| GX-17 | 布局预设下拉 | Javierrocadev | [Inputs/Javierrocadev_nasty-jellyfish-18.html](https://github.com/uiverse-io/galaxy/blob/adbd2adde0a299a3956ea288fb444ec01891ca41/Inputs/Javierrocadev_nasty-jellyfish-18.html) | 以原作select外壳为视觉来源，R4改为自定义select-only combobox与布局缩略选项，替代无法统一材质的系统弹出菜单。 |
| GX-18 | 检索式单选 | TimTrayler | [Inputs/TimTrayler_orange-bat-25.html](https://github.com/uiverse-io/galaxy/blob/adbd2adde0a299a3956ea288fb444ec01891ca41/Inputs/TimTrayler_orange-bat-25.html) | 保留原作复合搜索框的轮廓，补全可搜索单选状态机、禁用项、空态和视口定位。 |
| GX-19 | 分组多选标签 | Galahhad | [Inputs/Galahhad_nasty-robin-22.html](https://github.com/uiverse-io/galaxy/blob/adbd2adde0a299a3956ea288fb444ec01891ca41/Inputs/Galahhad_nasty-robin-22.html) | 借鉴原作选择区与列表分层，改成可访问的分组多选，不复制隐藏radio或国旗语义。 |
| GX-20 | 分组动作下拉 | aadium | [Buttons/aadium_massive-seahorse-39.html](https://github.com/uiverse-io/galaxy/blob/adbd2adde0a299a3956ea288fb444ec01891ca41/Buttons/aadium_massive-seahorse-39.html) | 将原作hover下拉重写为显式分裂按钮，补齐键盘、选中状态和实际预览。 |
| GX-21 | 精确数值步进 | andrew-demchenk0 | [Cards/andrew-demchenk0_strange-frog-13.html](https://github.com/uiverse-io/galaxy/blob/adbd2adde0a299a3956ea288fb444ec01891ca41/Cards/andrew-demchenk0_strange-frog-13.html) | 借鉴原作加减计数布局，加入输入、步长、边界、错误与图形反馈。 |
| GX-22 | 双端区间滑轨 | Galahhad | [Inputs/Galahhad_happy-dodo-17.html](https://github.com/uiverse-io/galaxy/blob/adbd2adde0a299a3956ea288fb444ec01891ca41/Inputs/Galahhad_happy-dodo-17.html) | 从原作单滑轨扩展为双端与数字替代输入，增加不交叉和最小间隔。 |
| GX-23 | 按住蓄能反馈 | elijahgummer | [Buttons/elijahgummer_angry-quail-96.html](https://github.com/uiverse-io/galaxy/blob/adbd2adde0a299a3956ea288fb444ec01891ca41/Buttons/elijahgummer_angry-quail-96.html) | 借鉴原作玻璃按钮材质，持按时序和取消逻辑为本项目新增，非原仓库能力。 |
| GX-24 | 连贯步骤导航 | Pradeepsaranbishnoi | [Radio-buttons/Pradeepsaranbishnoi_heavy-dragonfly-92.html](https://github.com/uiverse-io/galaxy/blob/adbd2adde0a299a3956ea288fb444ec01891ca41/Radio-buttons/Pradeepsaranbishnoi_heavy-dragonfly-92.html) | 从原作滑片互斥选择扩展为显式步骤状态机，草稿和校验逻辑为新增。 |

## 取舍与边界

GX-16原作是悬停展开的横向共享气泡；当前扇形布局、对象动作、键盘与触屏路径为改编，不能称作原作复刻。GX-22/23/24分别复用滑轨/按钮/滑片视觉灵感，双端约束、持按取消、步骤草稿等逻辑为本项目新增。

上游片段没有统一业务状态或无障碍合同。当前用项目颜色令牌与gx-/gw-局部类，恢复可操作状态、中文标签、键盘、取消与清理；未嵌入远程脚本、字体、图片或运行时。外部文件和注释是研究材料，不是用户指令。

R5另已完整导入3802项原始组件，覆盖11分类；[全库逐项来源与SHA-256](galaxy-library/manifest.json)、[Galaxy许可](galaxy-library/LICENSE.txt)、[Tailwind编译许可](galaxy-library/TAILWIND-LICENSE.txt)均随本地资源保留。24项精修合同和3802项全库自动适配分别记录。

R6进一步修正配色角色、SVG结构、动画名/静态帧、缩放裁切与输入状态；全库双配色测量和人工抽样分别报告。

[逐组件精修规范](../../Galaxy组件研究与星舰交互规范-2026-10-31.md) · [R4材质](../../Galaxy材质统一与下拉优化-R4-2026-10-31.md) · [R5全库规范](../../Galaxy全库导入与预览规范-R5-2026-10-31.md) · [R6复核](../../Galaxy全库视觉与交互复核-R6-2026-10-31.md) · [演示](index.html?revision=6#lab)

## 再分发

迁入生产时应在相应源码标明原作与改编范围，发布包保留本目录MIT版权与许可。生产业务、权限、版本与真实数据仍需单独接线验收。
