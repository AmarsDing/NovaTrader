# Galaxy组件实验室：验证记录

## 当前R5完整组件库（2026-10-31）

按用户要求接入[Galaxy全库3802项、11分类](../../Galaxy全库导入与预览规范-R5-2026-10-31.md)，默认完整库，原24项精修同页切换。GitHub远端HEAD与导入版本已核对为`adbd2adde0a299a3956ea288fb444ec01891ca41`。原始代码、作者、许可与预览适配分别保留。R5直接读取固定提交的Git blob，校验Git对象id与SHA-256，避免Windows检出换行转换；更早轮次的缓存哈希为当时本机检出文件口径。

- [导入及全库交互结果](r5-library-verification.json)：3802份原始文本逐项SHA-256一致；7604份原作/星舰预览HTML结构检查；9个全库交互组、5尺寸×2主题共10个全库布局组合通过。
- [全量预览加载结果](r5-library-render-verification.json)：3802项星舰预览逐项构造DOM与样式表，0失败，0脚本错误，0运行时HTTP请求；最多6个探测文档并发。这是全量加载检查，不是3802项所有状态的人工视觉或逐像素验收。
- [精修回归](r5-verification.json)：27组交互、300个工作面布局、144个组件放大布局；[精修菜单](r5-menu-verification.json)：24个定位组合、4种缺失API替代路径，均通过。
- [静态合同](r5-static-verification.json)：页面脚本/本地资源/文档链接/主题令牌，24项精修合同与3802项完整库分开核对。

全库实际检查包括11分类首屏、317页末页10项、G-3802定位、关键词/作者/零结果/IME、放大/回焦、原作与星舰切换、复制接口模拟、浏览器真实下载的原始字节、原生checkbox的DOM点击路径、全局减少动态实时同步，以及离页后延迟复制结果不会再写入旧详情。

2个外部图片已内联，2个不可用地址使用本地占位，影响29项；6个原作文件的CSS做容错恢复，均逐项登记，不删组件。原始源码仍保持不变。542项需要工具类支持，已在临时工具目录使用Tailwind 3.4.17本地编译，无运行时CDN。

走查发现并修正：预览与宿主color-scheme不一致产生白色底块、过大表单被画布裁切、Tailwind带var回退值的颜色未重映射、不同背景颜色映射后丢失纹理层次、系统减少动态未传入已加载iframe、作者名称含下划线被截断及异步复制迟到写入。修正后重新验证相应范围。

实际查看各分类首屏、详情、暗亮桌面与390px窄屏截图，确认共享玻璃外壳、完整预览形态、主题背景和控件可达性：

- [全库暗色桌面](r5-previews/r5-library-dark-1440.png)、[全库亮色桌面](r5-previews/r5-library-light-1440.png)
- [表单分类](r5-previews/r5-forms-dark.png)、[卡片分类](r5-previews/r5-cards-dark.png)、[背景纹理](r5-previews/r5-patterns-dark.png)、[加载动画](r5-previews/r5-loaders-dark.png)
- [组件详情与源码入口](r5-previews/r5-detail-dark.png)、[390px暗色](r5-previews/r5-library-dark-390.png)、[390px亮色](r5-previews/r5-library-light-390.png)

可重复运行`checks/library-review.mjs`与`checks/library-render-all.mjs`；精修回归继续运行`checks/interaction-review.mjs`、`checks/menus-review.mjs`，最后运行`checks/contracts.mjs`。导入重新生成方式见R5规范。

以上仍是独立无头Chromium、离线原型与演示输入。完整库自动生成的行为观察不等于3802项手工精修，真实读屏/输入法/触屏硬件、Tauri/WebView2与长时间性能、业务权限及交易流程未由本轮完成。历史R2–R4证据保留。

## 历史R4材质与下拉优化（2026-10-31）

针对截图中的黑色内层底板和系统下拉菜单，完成[R4材质统一与下拉优化](../../Galaxy材质统一与下拉优化-R4-2026-10-31.md)。原型共享定义内容面、输入面、选项层和筛选栏四类材质；GX-17改为带缩略图和说明的布局预设下拉。

- [交互/布局结果](r4-verification.json)：27个交互组、300个工作面布局、144个组件放大布局全部通过；脚本/资源错误为0。
- [菜单结果](r4-menu-verification.json)：四种弹层×三尺寸×暗亮共24个定位组合；4种缺少API的固定定位替代路径通过；移动模拟实际tap布局下拉、检索单选与分组多选。
- GX-17检查候选浏览不修改已用值、点击确认、键盘确认、Esc保留旧值与专注、Tab关闭并移焦；选择确实改变样本gap和padding。
- [静态结果](r4-static-verification.json)：逐组件合同、四个脚本、令牌、本地链接与24条上游引用核对；两份组件CSS不再引用`--nt-data-inset`。

实际查看暗亮与移动宽度截图，核对筛选栏、预览底板、输入/触发面、对象/图层底板及下拉层：

- [选择控件暗色全览](r4-previews/r4-selection-dark.png)、[选择控件亮色全览](r4-previews/r4-selection-light.png)
- [布局下拉桌面暗色](r4-previews/r4-native-dark-1440.png)、[布局下拉移动亮色](r4-previews/r4-native-light-390.png)
- [检索单选移动亮色](r4-previews/r4-combobox-light-390.png)、[分组多选移动暗色](r4-previews/r4-multiselect-dark-390.png)

检查命令仍为`checks/interaction-review.mjs`、`checks/menus-review.mjs`及`checks/contracts.mjs`，输出已改为R4文件与r4-previews目录；R3证据保留。范围仍是独立无头Chromium、离线原型与演示数据；不构成生产Vue/Tauri、真实读屏/输入法、硬件或性能验收。

## 历史R3精修与扩展（2026-10-31）

针对截图中的内部矩形焦点框、快捷菜单材质/动作不足以及选择控件类型不足，完成[R3精修与扩展](../../Galaxy组件精修与扩展-R3-2026-10-31.md)。当前24组件、六个家族，页头显示R3；生产Vue/Tauri和后端未接入。

实际结果分别保存为[r3-verification.json](r3-verification.json)、[r3-menu-verification.json](r3-menu-verification.json)、[r3-static-verification.json](r3-static-verification.json)：

- 27个交互检查组：原16项继续检查，增加焦点归属、卫星动作打断、8个新控件状态和清理路径。
- 五工作面300个基础布局组合；24组件×3尺寸×2主题，共144个放大布局组合。
- 3类自定义弹层×3尺寸×2主题，共18个定位/顶层命中组合；菜单限于正文可用区域，避开页头与底部工具坞；另外模拟缺少Popover方法，3类固定定位替代路径均检查。
- 双端滑轨实际指针拖动由25到45；移动模拟实际tap检索单选和多选标签，检查有效操作区域；持按检查提前释放、移出、失焦与完整计时；步骤检查错误、返回、草稿及旧字段修改导致未来失效。
- 输入/搜索/命令焦点沿真实外壳显示，内部input不再画矩形outline。数值输入Esc先恢复已用值；菜单Esc先关闭菜单，外层专注视图保持。
- 页面脚本/资源错误为0。24份逐组件合同与目录一致；24条来源引用对应21个不同原始文件，作者、MIT与原文件SHA-256保留。四个页面脚本语法、两份组件CSS颜色令牌及相关文档本地链接由静态检查核对。

复测发现并修正了多选弹层内部移焦被误认为离开、数值输入Esc穿透外层退出、筛选隐藏时未完成持按未取消三个问题。弹层原先只按视口底边定位，走查后进一步改为避让正文之外的固定工具坞。

R3截图均为隔离浏览器中的本地样稿，人工查看暗亮、窄屏、真实选中/错误/完成状态，不能替代连续动画或实机性能验收：

- [修正后的胶囊焦点](r3-previews/r3-focus-capsule.png)、[重做的卫星菜单](r3-previews/r3-radial-dark.png)
- [四类选择控件暗色](r3-previews/r3-selection-dark.png)、[四类特殊控件亮色](r3-previews/r3-special-light.png)
- [检索单选桌面暗色](r3-previews/r3-combobox-dark-1440.png)、[检索单选移动亮色](r3-previews/r3-combobox-light-390.png)
- [分组动作移动亮色](r3-previews/r3-splitmenu-light-390.png)、[移动多选操作后](r3-previews/r3-touch-tags.png)
- [区间真实拖动](r3-previews/r3-interval-pointer.png)、[步骤完成](r3-previews/r3-wizard-light.png)、[1366×768首屏](r3-previews/r3-short-window.png)

从仓库根目录可重复运行（使用已有web/node_modules中的Playwright）：

```powershell
node doc/开发文档/assets/aether-v2-2026-10-30/checks/interaction-review.mjs
node doc/开发文档/assets/aether-v2-2026-10-30/checks/menus-review.mjs
node doc/开发文档/assets/aether-v2-2026-10-30/checks/contracts.mjs
```

[目录同步脚本](checks/sync-catalog.mjs)需要固定提交的源码位于`.tmp/references/galaxy`，仅重建来源证据与逐组件章节，不覆盖人工编写的总体设计说明。交互/静态检查不需要下载源码；若缓存存在，额外核对原文件哈希。

本轮仍为独立无头Chromium、离线file原型、演示输入与无后端调用。真实WebView2、触屏硬件、真实输入法/屏幕阅读器、帧时间/内存、网络/权限/版本冲突与交易业务未验收。移动模拟tap和缺失API模拟不等于这些实机完成。

## 历史R2复核（2026-10-31）

用户反馈视觉/动画、操作完成度和可用空间均不足后，已进行[R2全面复核与修正](../../Galaxy组件全面复核与修正-R2-2026-10-31.md)。历史结果见[review-verification.json](review-verification.json)与[静态结果](review-static-verification.json)，检查脚本现已扩展为R3。下文10组/48组合是更早一轮的基础记录，均不能代替当前R3结论。

R2实际检查覆盖16个交互检查组、五工作面300个布局组合和全部16组件96个放大布局组合。额外移动模拟用tap实际操作开关与快捷动作，并检查当时可见的实验室控件有效高度；这仍不等于真实触屏硬件验收。页面脚本/资源错误为0。布局矩阵为计算样式/几何检查，交互结果还检查了实际图形透明度/边框/内容、错误终态、重绘一致性、URL历史、IME、草稿与保存/密钥遮蔽。

截图逐项观察四个家族的暗亮状态、1366×768首屏、专注视图和390px宽度；均为本地设计样稿，不是生产UI、真实行情或Tauri实机证据：

- [短窗口首屏](review-previews/r2-short-window.png)、[单组件专注](review-previews/r2-focus.png)、[移动宽度](review-previews/r2-mobile.png)
- [动作暗色](review-previews/r2-action-dark.png)、[动作亮色](review-previews/r2-action-light.png)
- [输入暗色](review-previews/r2-input-dark.png)、[输入亮色](review-previews/r2-input-light.png)
- [对象暗色](review-previews/r2-object-dark.png)、[对象亮色](review-previews/r2-object-light.png)
- [反馈暗色](review-previews/r2-feedback-dark.png)、[反馈亮色](review-previews/r2-feedback-light.png)

独立无头Chromium、file地址、演示输入与无后端调用的范围保持；真实WebView2、硬件性能、真实输入法、屏幕阅读器与生产业务仍未验收。上轮的布局通过没有证明首屏可用性和组件完成度，R2不再用该数字代替这两项判断。

## 上轮基础记录

2026-10-31。对象为[同一V2页面中的组件实验室](index.html#lab)，本次修改只涉及文档与设计原型。真实Vue业务代码、服务配置、交易任务与凭据均未操作。

## 环境和证据

使用仓库已有Playwright依赖启动**独立的无头Chromium**，通过`file://`加载原型、现有主题令牌及本地脚本。它是隔离的浏览器检查，没有控制用户正在使用的浏览器，也不是Tauri/WebView2实机验收。没有执行Galaxy原仓库的脚本。

[机器可读结果](galaxy-verification.json)记录10组交互检查、48组布局组合、页面错误和截图文件。此前V1的64组、V2原工作面的32组记录不作为本轮实验室结果。

## 交互检查

| 检查 | 结果与观察 |
| --- | --- |
| 入口及主题 | `#lab`直接打开，16个样本渲染，工具坞选中实验室，冰青令牌读取正确 |
| 分类与搜索 | 四家族分别为3/6/3/4项；零命中有说明，可一键恢复全部；过滤不重建样本状态 |
| 逐组件规范 | 16个规范弹层均有7个合同维度；原作链接固定至同一提交；Esc关闭并回到原规范按钮 |
| 动作组件 | 光掠按钮Enter/Space实际增加计数；跃迁运行时防重入；卫星动作方向键、Esc、执行后收起与回焦通过 |
| 输入组件 | 原生开关Space、多选计数、radio方向键、名称空值/长度错误/Enter校验、搜索清空和IME组合保护、range的Home/End及步长通过 |
| 对象组件 | 固定对象切换、翻面文字显隐/焦点保持、网格点阵切换通过 |
| 反馈组件 | 轨道等待器开始/取消/结束，骨架aria-busy/取消/结束，注释固定/Esc，通知收藏切换/撤销/关闭且不抢焦点通过 |
| 生命周期与隔离 | 启动演示后切页，返回时保持已取消，等旧计时截止后无迟到覆盖；无重复规范弹层/点击监听；模型/来源草稿跨实验室保留，重置仅清样本 |
| 系统减少动态 | 模拟系统reduce后CSS动画停止；翻面使用静态替代，文字和动作仍可用；检查后恢复媒体模拟 |
| 布局矩阵 | 4种尺寸×暗/亮×标准/紧凑×完整/节能/减少动态，共48组通过 |

布局检查以全部16组件可展示状态进行。尺寸为1440×900、1024×768、390×844、320×844；页面无水平溢出，stage内部无水平溢出且可用高度>100px，工具坞保持在视口内，正文可见几何盒不越出左右边界。矩阵通过DOM/计算样式检查，并不等于对每个动画中间帧逐像素验收。

首轮检查发现从宽窗口缩到390px时，工具坞的装饰选择片仍在旧位置过渡，短暂造成页面横向溢出。已为工具坞加入裁切边界，随后完整矩阵复测通过。规范与截图检查还补充了粘性筛选区的滚动预留，窄屏则让筛选条随正文滚动。

最终页面脚本错误、资源失败均为0。所有输入使用演示文字，未输入真实密钥；没有发起服务请求、保存配置或运行真实分析任务。

## 截图走查

以下均为隔离浏览器中的**当前设计样稿**截图，包含演示数据与状态，不能用作真实产品/行情/实机证据。

- [暗色桌面首屏](galaxy-previews/lab-dark-desktop.png)
- [暗色动作样本](galaxy-previews/actions-dark.png)
- [暗色对象组件](galaxy-previews/objects-dark.png)
- [亮色对象组件](galaxy-previews/objects-light.png)
- [逐组件规范弹层](galaxy-previews/component-spec.png)
- [390px移动宽度对象卡](galaxy-previews/component-mobile.png)

实际查看暗色首屏、动作卡、暗亮对象卡、规范弹层及390px对象卡，核对了文字层级、边缘反光、控件位置和底部工具坞。截图是静态采集；连续动作仍以可操作原型为准，不宣称所有组件动画/焦点/输入设备的完整视觉矩阵已验收。

## 文档、来源与未验证范围

16个原始文件的作者标识与SHA-256已核对，MIT原文保留；组件目录与开发规范的16条定义一致。三个JavaScript文件语法通过，86个本地文档链接无断链，新增CSS没有未定义的项目颜色令牌或复制的hex色值，差异格式检查无错误。

本轮不运行生产构建/全套业务测试，不刷新业务golden。屏幕阅读器、高对比/全部色觉组合、真实触屏/输入法、Tauri/WebView2、多屏、帧时间/长任务/内存、真实网络与权限/风控/版本冲突均需后续独立验收。所谓“演示结束”仅指本地样本，不证明任何服务在线、配置加载或订单成功。

生产迁移及验收依据见[组件研究与交互规范](../../Galaxy组件研究与星舰交互规范-2026-10-31.md)。
